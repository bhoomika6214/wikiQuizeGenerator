const generateQuiz = (paragraphs) => {
  const quiz = [];

  paragraphs.forEach((para, index) => {
    if (quiz.length >= 5) return;

    const match = para.match(/^(.+?) was (.+?)\./i);
    if (!match) return;

    const subject = match[1];
    const answer = match[2];

    quiz.push({
      question: `What was ${subject}?`,
      options: shuffle([
        answer,
        "A scientist",
        "A political leader",
        "An artist"
      ]),
      answer,
      difficulty: index < 2 ? "easy" : "medium",
      explanation: para
    });
  });

  return quiz;
};

const shuffle = (arr) => arr.sort(() => Math.random() - 0.5);

module.exports = generateQuiz;
