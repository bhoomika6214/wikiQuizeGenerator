import React, { useEffect, useState } from "react";
import axios from "axios";
import QuizDetailsModal from "./QuizDetailsModal";

export default function History() {
  const [quizzes, setQuizzes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [selectedQuiz, setSelectedQuiz] = useState(null);

  useEffect(() => {
    fetchHistory();
  }, []);

  const fetchHistory = async () => {
    setLoading(true);
    setError("");
    try {
      const res = await axios.get("http://localhost:5000/api/quiz/history");
      setQuizzes(res.data);
    } catch (err) {
      setError("Failed to fetch history");
    } finally {
      setLoading(false);
    }
  };

  const openDetails = async (id) => {
    try {
      const res = await axios.get(`http://localhost:5000/api/quiz/${id}`);
      setSelectedQuiz(res.data);
    } catch (err) {
      alert("Failed to fetch quiz details");
    }
  };

  const closeModal = () => setSelectedQuiz(null);

  return (
    <div style={{ maxWidth: 900, margin: "auto" }}>
      <h2>Past Quizzes</h2>
      {loading && <p>Loading...</p>}
      {error && <p style={{ color: "red" }}>{error}</p>}

      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ borderBottom: "1px solid #ccc" }}>
            <th>Title</th>
            <th>URL</th>
            <th>Created At</th>
            <th>Details</th>
          </tr>
        </thead>
        <tbody>
          {quizzes.map((quiz) => (
            <tr key={quiz._id} style={{ borderBottom: "1px solid #eee" }}>
              <td>{quiz.title}</td>
              <td>
                <a href={quiz.url} target="_blank" rel="noreferrer">
                  Link
                </a>
              </td>
              <td>{new Date(quiz.createdAt).toLocaleString()}</td>
              <td>
                <button onClick={() => openDetails(quiz._id)}>Details</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedQuiz && (
        <QuizDetailsModal quiz={selectedQuiz} onClose={closeModal} />
      )}
    </div>
  );
}
