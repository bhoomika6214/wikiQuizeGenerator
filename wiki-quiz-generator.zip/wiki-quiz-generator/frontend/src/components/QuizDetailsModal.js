import React from "react";
import QuizCard from "./QuizCard";

export default function QuizDetailsModal({ quiz, onClose }) {
  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        height: "100vh",
        width: "100vw",
        backgroundColor: "rgba(0,0,0,0.5)",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        zIndex: 1000,
      }}
      onClick={onClose}
    >
      <div
        style={{
          backgroundColor: "white",
          borderRadius: 8,
          maxWidth: 800,
          width: "90%",
          padding: 20,
          maxHeight: "90vh",
          overflowY: "auto",
          position: "relative",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          style={{
            position: "absolute",
            right: 15,
            top: 15,
            fontSize: 18,
            border: "none",
            background: "none",
            cursor: "pointer",
          }}
        >
          &times;
        </button>

        <h2>{quiz.title}</h2>
        <p>{quiz.summary}</p>

        <div>
          {quiz.quiz.map((q, i) => (
            <QuizCard key={i} question={q} />
          ))}
        </div>

        {quiz.relatedTopics && quiz.relatedTopics.length > 0 && (
          <>
            <h4>Related Topics</h4>
            <ul>
              {quiz.relatedTopics.map((topic, i) => (
                <li key={i}>{topic}</li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  );
}
