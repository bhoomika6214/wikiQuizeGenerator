import React from "react";

export default function QuizCard({ question }) {
  return (
    <div style={{
      border: "1px solid #ccc",
      borderRadius: 5,
      padding: 15,
      marginBottom: 15,
      backgroundColor: "#fafafa"
    }}>
      <p><strong>Q:</strong> {question.question}</p>
      <ul style={{ listStyle: "none", paddingLeft: 0 }}>
        {question.options.map((opt, i) => (
          <li key={i} style={{ marginBottom: 5 }}>
            <strong>{String.fromCharCode(65 + i)}.</strong> {opt}
          </li>
        ))}
      </ul>
      <p><strong>Answer:</strong> {question.answer}</p>
      <p><strong>Explanation:</strong> {question.explanation}</p>
      <p><strong>Difficulty:</strong> {question.difficulty}</p>
    </div>
  );
}
