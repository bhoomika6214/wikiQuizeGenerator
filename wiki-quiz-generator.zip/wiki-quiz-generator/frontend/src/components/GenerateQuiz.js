import React, { useState } from "react";
import axios from "axios";
import QuizCard from "./QuizCard";

export default function GenerateQuiz() {
  const [url, setUrl] = useState("");
  const [quizData, setQuizData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // NEW: State for Take Quiz mode
  const [takeQuizMode, setTakeQuizMode] = useState(false);
  const [userAnswers, setUserAnswers] = useState({});
  const [score, setScore] = useState(null);

  const handleGenerate = async () => {
    if (!url) return setError("Please enter a Wikipedia URL");

    setLoading(true);
    setError("");
    setQuizData(null);
    setTakeQuizMode(false);
    setUserAnswers({});
    setScore(null);

    try {
      const response = await axios.post("http://localhost:5000/api/quiz/generate", { url });
      setQuizData(response.data);
    } catch (err) {
      setError("Failed to generate quiz. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (questionIndex, optionIndex) => {
    setUserAnswers(prev => ({
      ...prev,
      [questionIndex]: optionIndex,
    }));
  };

  const handleSubmitQuiz = () => {
    if (!quizData) return;

    let calculatedScore = 0;
    quizData.quiz.forEach((q, i) => {
      // correct answer string
      const correctAnswer = q.answer.trim();

      // user selected option string
      const selectedIndex = userAnswers[i];
      if (selectedIndex === undefined) return; // unanswered

      const selectedAnswer = q.options[selectedIndex].trim();

      if (selectedAnswer === correctAnswer) {
        calculatedScore += 1;
      }
    });

    setScore(calculatedScore);
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div style={{ maxWidth: 800, margin: "auto" }}>
      <h2>Generate Quiz</h2>
      <input
        type="text"
        placeholder="Enter Wikipedia article URL"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        style={{ width: "100%", padding: 8, marginBottom: 10 }}
        disabled={takeQuizMode}
      />
      <button onClick={handleGenerate} disabled={loading || takeQuizMode}>
        Generate Quiz
      </button>

      {error && <p style={{ color: "red" }}>{error}</p>}

      {quizData && !takeQuizMode && (
        <>
          <h3>{quizData.title}</h3>
          <p>{quizData.summary}</p>
          <button onClick={() => setTakeQuizMode(true)}>Take Quiz</button>

          <div>
            {quizData.quiz.map((q, i) => (
              <QuizCard key={i} question={q} />
            ))}
          </div>
          {quizData.relatedTopics && quizData.relatedTopics.length > 0 && (
            <div>
              <h4>Related Topics</h4>
              <ul>
                {quizData.relatedTopics.map((topic, i) => (
                  <li key={i}>{topic}</li>
                ))}
              </ul>
            </div>
          )}
        </>
      )}

      {/* Take Quiz Mode */}
      {quizData && takeQuizMode && (
        <>
          <h3>Take Quiz: {quizData.title}</h3>
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSubmitQuiz();
            }}
          >
            {quizData.quiz.map((q, i) => (
              <div
                key={i}
                style={{
                  border: "1px solid #ccc",
                  borderRadius: 5,
                  padding: 15,
                  marginBottom: 15,
                  backgroundColor: "#fafafa",
                }}
              >
                <p>
                  <strong>Q{i + 1}:</strong> {q.question}
                </p>
                {q.options.map((opt, idx) => (
                  <label key={idx} style={{ display: "block", marginBottom: 5 }}>
                    <input
                      type="radio"
                      name={`question-${i}`}
                      value={idx}
                      checked={userAnswers[i] === idx}
                      onChange={() => handleAnswerChange(i, idx)}
                      required
                    />{" "}
                    {String.fromCharCode(65 + idx)}. {opt}
                  </label>
                ))}
              </div>
            ))}

            <button type="submit">Submit Quiz</button>
          </form>

          {score !== null && (
            <p style={{ marginTop: 20, fontWeight: "bold" }}>
              Your Score: {score} / {quizData.quiz.length}
            </p>
          )}

          <button
            style={{ marginTop: 10 }}
            onClick={() => {
              setTakeQuizMode(false);
              setUserAnswers({});
              setScore(null);
            }}
          >
            Back to View Quiz
          </button>
        </>
      )}
    </div>
  );
}
