import React, { useState } from "react";
import GenerateQuiz from "./components/GenerateQuiz";
import History from "./components/History";

function App() {
  const [activeTab, setActiveTab] = useState("generate");

  return (
    <div style={{ padding: 20, maxWidth: 900, margin: "auto" }}>
      <h1>Wiki Quiz Generator</h1>
      <div style={{ marginBottom: 20 }}>
        <button
          onClick={() => setActiveTab("generate")}
          disabled={activeTab === "generate"}
          style={{ marginRight: 10 }}
        >
          Generate Quiz
        </button>
        <button
          onClick={() => setActiveTab("history")}
          disabled={activeTab === "history"}
        >
          Past Quizzes
        </button>
      </div>

      {activeTab === "generate" && <GenerateQuiz />}
      {activeTab === "history" && <History />}
    </div>
  );
}

export default App;
