const axios = require("axios");
const cheerio = require("cheerio");

const scrapeWikipedia = async (url) => {
  const { data } = await axios.get(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                    "AppleWebKit/537.36 (KHTML, like Gecko) " +
                    "Chrome/112.0.0.0 Safari/537.36"
    }
  });
  
  const $ = cheerio.load(data);

  const title = $("#firstHeading").text();

  let summary = "";
  $("#mw-content-text p").each((i, el) => {
    const text = $(el).text().trim();
    if (text.length > 120) {
      summary = text;
      return false;
    }
  });

  const sections = [];
  $("h2 span.mw-headline").each((i, el) => {
    sections.push($(el).text());
  });

  const paragraphs = [];
  $("#mw-content-text p").each((i, el) => {
    const text = $(el).text().trim();
    if (text.length > 60) paragraphs.push(text);
  });

  return { title, summary, sections, paragraphs };
};

module.exports = scrapeWikipedia;
