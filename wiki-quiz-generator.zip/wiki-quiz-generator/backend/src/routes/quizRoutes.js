const express = require("express");
const router = express.Router();

const {
  generateQuiz,
  getQuizHistory,
  getQuizById
} = require("../controllers/quizController");

// POST to generate quiz from URL
router.post("/generate", generateQuiz);

// GET list of past quizzes (history)
router.get("/history", getQuizHistory);

router.get("/quiz/:id", getQuizById);

module.exports = router;
