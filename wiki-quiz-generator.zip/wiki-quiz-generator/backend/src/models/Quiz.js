const mongoose = require("mongoose");

const QuizSchema = new mongoose.Schema({
  url: { type: String, required: true },
  title: String,
  summary: String,
  sections: [String],

  quiz: [
    {
      question: String,
      options: [String],
      answer: String,
      difficulty: String,
      explanation: String
    }
  ],

  relatedTopics: [String],
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("Quiz", QuizSchema);
