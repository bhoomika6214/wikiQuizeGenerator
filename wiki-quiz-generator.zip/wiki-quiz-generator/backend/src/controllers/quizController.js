const Quiz = require("../models/Quiz");
const scrapeWikipedia = require("../services/scraperService");
const generateQuiz = require("../services/quizGenerator");

exports.generateQuiz = async (req, res) => {
  try {
    const { url } = req.body;

    if (!url || !url.includes("wikipedia.org")) {
      return res.status(400).json({ error: "Invalid Wikipedia URL" });
    }

    const existingQuiz = await Quiz.findOne({ url });
    if (existingQuiz) {
      return res.json(existingQuiz);
    }

    const scrapedData = await scrapeWikipedia(url);
    const quiz = generateQuiz(scrapedData.paragraphs);

    const savedQuiz = await Quiz.create({
      url,
      title: scrapedData.title,
      summary: scrapedData.summary,
      sections: scrapedData.sections,
      quiz,
      relatedTopics: scrapedData.sections.slice(0, 5)
    });

    res.json(savedQuiz);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.getQuizHistory = async (req, res) => {
  try {
    // Find all quizzes, only return needed fields, sorted by newest first
    const quizzes = await Quiz.find()
      .select("title url createdAt")
      .sort({ createdAt: -1 });

    res.json(quizzes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.getQuizById = async (req, res) => {
  try {
    const quiz = await Quiz.findById(req.params.id);
    if (!quiz) return res.status(404).json({ error: "Quiz not found" });
    res.json(quiz);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

